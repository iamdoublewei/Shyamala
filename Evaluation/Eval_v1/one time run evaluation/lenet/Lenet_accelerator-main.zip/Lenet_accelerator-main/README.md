# Lenet_accelerator
Digit recognition CNN model implemented for MSP430FR5994 device
