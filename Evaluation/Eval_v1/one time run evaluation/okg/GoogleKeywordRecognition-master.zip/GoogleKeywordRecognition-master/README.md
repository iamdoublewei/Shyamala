# GoogleKeywordRecognition
DNN inference for msp430
